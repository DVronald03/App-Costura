/**
 * schemas.ts — Modelo de dados. Todas as medidas em centímetros.
 */
export type Gender = 'female' | 'male';
export type FitLevel = 'tight' | 'comfortable' | 'loose'; // Justo | Confortável | Solto
export type GarmentType =
  | 'skirt'        // Saia
  | 'menPants'     // Calça Masculina
  | 'womenPants'   // Calça Feminina
  | 'menShirt'     // Camisa Masculina
  | 'womenBlouse'  // Blusa Feminina
  | 'dress'        // Vestido
  | 'sleeve';      // Manga

export interface FemaleMeasurements {
  fullBust: number;        // busto completo
  highBust: number;        // busto alto (reservado p/ ajustes de largura superior)
  bustSeparation: number;  // separação de busto (distância entre os bicos)
  bustHeight: number;      // altura do busto (ponto do pescoço/ombro até o bico)
  frontLength: number;     // comprimento frente até cintura
  backLength: number;      // comprimento costas até cintura
  backWidth: number;       // largura costas
  shoulder: number;        // comprimento do ombro
  neck: number;            // circunferência do pescoço
  armholeDepth: number;    // cava (profundidade)
  waist: number;           // cintura
  highHip: number;         // quadril alto
  lowHip: number;          // quadril baixo (usado como quadril principal)
  hipHeight: number;       // altura do quadril (da cintura)
  crotchHeight: number;    // altura do gancho
  skirtLength: number;     // comprimento da saia
  pantsLength: number;     // comprimento da calça (lateral)
  sleeveLength: number;    // comprimento da manga
  thigh: number;           // coxa
  knee: number;            // joelho
  hem: number;             // barra
  bicep?: number;          // opcional (estimado a partir da cava se ausente)
  wrist?: number;          // opcional
}

export interface MaleMeasurements {
  chest: number;               // tórax
  waist: number;               // cintura
  hip: number;                 // quadril
  shoulderToShoulder: number;  // ombro a ombro
  frontLength: number;         // comprimento do tórax (frente)
  backLength: number;          // comprimento costas
  crotchHeight: number;        // altura do gancho (gavião) — informativa; a calça usa outseam - inseam
  outseam: number;             // comprimento da perna externo
  inseam: number;              // comprimento da perna interno
  neck: number;                // pescoço
  wrist: number;               // punho
  sleeveLength: number;        // comprimento da manga
  thigh: number;               // coxa
  knee: number;                // joelho
  hem: number;                 // barra
  bicep?: number;
}

export type BodyMeasurements =
  | { gender: 'female'; data: FemaleMeasurements }
  | { gender: 'male'; data: MaleMeasurements };

/** Folgas de vestibilidade em cm (circunferência total, não por painel). */
export interface EaseSet {
  chest: number; // busto / tórax
  waist: number;
  hip: number;
  thigh: number;
}
export type EaseTable = Record<Gender, Record<FitLevel, EaseSet>>;

export const DEFAULT_EASE_TABLE: EaseTable = {
  female: {
    tight:       { chest: 4,  waist: 2, hip: 4,  thigh: 4 },
    comfortable: { chest: 8,  waist: 4, hip: 6,  thigh: 8 },
    loose:       { chest: 14, waist: 8, hip: 10, thigh: 12 },
  },
  male: {
    tight:       { chest: 8,  waist: 4,  hip: 6,  thigh: 6 },
    comfortable: { chest: 12, waist: 6,  hip: 8,  thigh: 8 },
    loose:       { chest: 20, waist: 10, hip: 12, thigh: 12 },
  },
};

export interface PatternConfig {
  gender: Gender;
  garment: GarmentType;
  fit: FitLevel;
  easeTable: EaseTable;     // editável pelo usuário (seletores numéricos)
  seamAllowance: number;    // 1.0 ou 1.5 (qualquer valor > 0 é aceito)
  sizeLabel: string;        // ex.: "P", "M", "38"
}

export function defaultConfig(
  gender: Gender,
  garment: GarmentType,
  overrides: Partial<PatternConfig> = {},
): PatternConfig {
  return {
    gender,
    garment,
    fit: 'comfortable',
    easeTable: structuredClone(DEFAULT_EASE_TABLE),
    seamAllowance: 1.0,
    sizeLabel: 'M',
    ...overrides,
  };
}

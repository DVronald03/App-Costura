/**
 * exporters.ts — Exportação vetorial: PDF (página única ou grade A4 com sobreposição) e DXF 2D.
 */
import PDFDocument from 'pdfkit';
import { PatternPiece, Point, Segment, flatten, layoutPieces, seamOutline } from './geometry';

export interface ExportOptions { seamAllowance: number; gap?: number; maxRowWidth?: number }

// ───────────────────────── DXF (R12 / AC1009, unidade: cm) ─────────────────────────
export function exportDxf(pieces: PatternPiece[], opts: ExportOptions): string {
  const { pieces: laid } = layoutPieces(pieces, opts.seamAllowance, opts.gap ?? 5, opts.maxRowWidth ?? 140);
  const g = (code: number, v: string | number) => `${code}\n${v}\n`;
  const layers: [string, number][] = [['PIECE', 7], ['SEAM', 8], ['GRAIN', 5], ['DARTS', 1], ['MARKS', 6], ['TEXT', 2]];
  const Y = (y: number) => -y; // DXF tem Y para cima

  let s = g(0, 'SECTION') + g(2, 'HEADER') + g(9, '$ACADVER') + g(1, 'AC1009') + g(0, 'ENDSEC');
  s += g(0, 'SECTION') + g(2, 'TABLES');
  s += g(0, 'TABLE') + g(2, 'LTYPE') + g(70, 1) + g(0, 'LTYPE') + g(2, 'CONTINUOUS') + g(70, 0) + g(3, 'Solid line') + g(72, 65) + g(73, 0) + g(40, 0) + g(0, 'ENDTAB');
  s += g(0, 'TABLE') + g(2, 'LAYER') + g(70, layers.length);
  for (const [n, c] of layers) s += g(0, 'LAYER') + g(2, n) + g(70, 0) + g(62, c) + g(6, 'CONTINUOUS');
  s += g(0, 'ENDTAB') + g(0, 'ENDSEC') + g(0, 'SECTION') + g(2, 'ENTITIES');

  const poly = (pts: Point[], layer: string, closed: boolean) => {
    let r = g(0, 'POLYLINE') + g(8, layer) + g(66, 1) + g(70, closed ? 1 : 0);
    for (const p of pts) r += g(0, 'VERTEX') + g(8, layer) + g(10, p.x.toFixed(4)) + g(20, Y(p.y).toFixed(4)) + g(30, 0);
    return r + g(0, 'SEQEND') + g(8, layer);
  };
  for (const p of laid) {
    const pts = flatten(p.segments, 24);
    s += poly(pts, 'PIECE', true) + poly(seamOutline(p, opts.seamAllowance), 'SEAM', true);
    for (const d of p.darts) s += poly(d, 'DARTS', false);
    s += g(0, 'LINE') + g(8, 'GRAIN') + g(10, p.grain.from.x) + g(20, Y(p.grain.from.y)) + g(30, 0) + g(11, p.grain.to.x) + g(21, Y(p.grain.to.y)) + g(31, 0);
    if (p.bustPoint) s += g(0, 'CIRCLE') + g(8, 'MARKS') + g(10, p.bustPoint.x) + g(20, Y(p.bustPoint.y)) + g(30, 0) + g(40, 0.3);
    const cx = pts.reduce((a, q) => a + q.x, 0) / pts.length, cy = pts.reduce((a, q) => a + q.y, 0) / pts.length;
    s += g(0, 'TEXT') + g(8, 'TEXT') + g(10, cx.toFixed(3)) + g(20, Y(cy).toFixed(3)) + g(30, 0) + g(40, 1) + g(1, p.label ?? p.name);
  }
  return s + g(0, 'ENDSEC') + g(0, 'EOF');
}

// ───────────────────────── PDF vetorial ─────────────────────────
export interface PdfOptions extends ExportOptions {
  tileA4: boolean;      // true = divide em folhas A4 (impressão caseira)
  overlapCm?: number;   // sobreposição entre folhas (padrão 1 cm)
  pageMarginCm?: number;// margem de impressão (padrão 1 cm)
}
const K = 72 / 2.54; // pt por cm

function drawSegs(doc: PDFKit.PDFDocument, segs: Segment[]) {
  for (const s of segs) {
    if (s.t === 'M') doc.moveTo(s.p.x, s.p.y);
    else if (s.t === 'L') doc.lineTo(s.p.x, s.p.y);
    else if (s.t === 'C') doc.bezierCurveTo(s.c1.x, s.c1.y, s.c2.x, s.c2.y, s.p.x, s.p.y);
    else doc.closePath();
  }
}
function drawPoly(doc: PDFKit.PDFDocument, pts: Point[], closed: boolean) {
  pts.forEach((p, i) => (i ? doc.lineTo(p.x, p.y) : doc.moveTo(p.x, p.y)));
  if (closed) doc.closePath();
}

/** Desenha uma peça; o doc já deve estar com scale(K) (unidades em cm). */
function drawPiece(doc: PDFKit.PDFDocument, p: PatternPiece, sa: number) {
  doc.undash().lineWidth(0.05).strokeColor('#888').dash(0.5, { space: 0.3 });
  drawPoly(doc, seamOutline(p, sa), true); doc.stroke(); doc.undash();

  doc.lineWidth(0.08).strokeColor('#111'); drawSegs(doc, p.segments); doc.stroke();
  doc.lineWidth(0.07).strokeColor('#c2410c');
  for (const d of p.darts) { drawPoly(doc, d, false); doc.stroke(); }

  const { from, to } = p.grain;
  doc.lineWidth(0.06).strokeColor('#111').moveTo(from.x, from.y).lineTo(to.x, to.y).stroke();
  doc.fillColor('#111');
  doc.polygon([from.x, from.y], [from.x - 0.6, from.y + 1.2], [from.x + 0.6, from.y + 1.2]).fill();
  doc.polygon([to.x, to.y], [to.x - 0.6, to.y - 1.2], [to.x + 0.6, to.y - 1.2]).fill();

  if (p.bustPoint) {
    const { x, y } = p.bustPoint;
    doc.lineWidth(0.06).strokeColor('#be123c').circle(x, y, 0.35).stroke()
      .moveTo(x - 0.6, y).lineTo(x + 0.6, y).moveTo(x, y - 0.6).lineTo(x, y + 0.6).stroke();
    doc.fillColor('#be123c').fontSize(0.9).text('BP', x + 0.6, y - 1.5, { lineBreak: false });
  }
  const pts = flatten(p.segments);
  const cx = pts.reduce((a, q) => a + q.x, 0) / pts.length, cy = pts.reduce((a, q) => a + q.y, 0) / pts.length;
  const label = p.label ?? p.name;
  doc.fillColor('#111').fontSize(1);
  doc.text(label, cx - doc.widthOfString(label) / 2, cy, { lineBreak: false });
}

export function exportPdf(pieces: PatternPiece[], opts: PdfOptions): Promise<Buffer> {
  const { pieces: laid, bounds } = layoutPieces(pieces, opts.seamAllowance, opts.gap ?? 5, opts.maxRowWidth ?? 140);
  const pad = 1, ox = bounds.minX - pad, oy = bounds.minY - pad;
  const W = bounds.maxX - bounds.minX + 2 * pad, H = bounds.maxY - bounds.minY + 2 * pad;

  const doc = new PDFDocument({ size: opts.tileA4 ? 'A4' : [W * K, H * K], margin: 0 });
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((res, rej) => { doc.on('end', () => res(Buffer.concat(chunks))); doc.on('error', rej); });

  if (!opts.tileA4) {
    doc.save().scale(K).translate(-ox, -oy);
    laid.forEach((p) => drawPiece(doc, p, opts.seamAllowance));
    doc.restore();
  } else {
    const pm = opts.pageMarginCm ?? 1, ov = opts.overlapCm ?? 1;
    const pw = 21 - 2 * pm, ph = 29.7 - 2 * pm, stepX = pw - ov, stepY = ph - ov;
    const cols = Math.max(1, Math.ceil((W - ov) / stepX)), rows = Math.max(1, Math.ceil((H - ov) / stepY));
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      if (r || c) doc.addPage();
      doc.save().translate(pm * K, pm * K).scale(K);
      doc.rect(0, 0, pw, ph).clip();
      doc.translate(-(ox + c * stepX), -(oy + r * stepY));
      laid.forEach((p) => drawPiece(doc, p, opts.seamAllowance));
      doc.restore();
      // marcas de registro nos cantos + identificação da folha (para colar)
      doc.save().lineWidth(0.5).strokeColor('#000');
      for (const [x, y] of [[pm, pm], [21 - pm, pm], [pm, 29.7 - pm], [21 - pm, 29.7 - pm]])
        doc.moveTo(x * K - 8, y * K).lineTo(x * K + 8, y * K).moveTo(x * K, y * K - 8).lineTo(x * K, y * K + 8).stroke();
      doc.fillColor('#000').fontSize(8)
        .text(`Folha ${r + 1}-${c + 1}  (${rows} linhas × ${cols} colunas)`, pm * K + 12, (29.7 - 0.7) * K, { lineBreak: false });
      doc.restore();
    }
  }
  doc.end();
  return done;
}

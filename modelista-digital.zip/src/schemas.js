"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_EASE_TABLE = void 0;
exports.defaultConfig = defaultConfig;
exports.DEFAULT_EASE_TABLE = {
    female: {
        tight: { chest: 4, waist: 2, hip: 4, thigh: 4 },
        comfortable: { chest: 8, waist: 4, hip: 6, thigh: 8 },
        loose: { chest: 14, waist: 8, hip: 10, thigh: 12 },
    },
    male: {
        tight: { chest: 8, waist: 4, hip: 6, thigh: 6 },
        comfortable: { chest: 12, waist: 6, hip: 8, thigh: 8 },
        loose: { chest: 20, waist: 10, hip: 12, thigh: 12 },
    },
};
function defaultConfig(gender, garment, overrides = {}) {
    return {
        gender,
        garment,
        fit: 'comfortable',
        easeTable: structuredClone(exports.DEFAULT_EASE_TABLE),
        seamAllowance: 1.0,
        sizeLabel: 'M',
        ...overrides,
    };
}

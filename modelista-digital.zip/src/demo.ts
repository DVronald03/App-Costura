import { mkdirSync, writeFileSync } from 'fs';
import { defaultConfig, BodyMeasurements } from './schemas';
import { generatePattern } from './patterns';
import { SvgRenderer } from './renderer';
import { exportDxf, exportPdf } from './exporters';

const body: BodyMeasurements = {
  gender: 'female',
  data: {
    fullBust: 92, highBust: 86, bustSeparation: 18, bustHeight: 26, frontLength: 42, backLength: 39.5,
    backWidth: 35, shoulder: 12.5, neck: 36, armholeDepth: 21, waist: 72, highHip: 88, lowHip: 98,
    hipHeight: 20, crotchHeight: 26, skirtLength: 60, pantsLength: 100, sleeveLength: 58, thigh: 58, knee: 38, hem: 34,
  },
};

(async () => {
  mkdirSync('out', { recursive: true });
  for (const garment of ['womenBlouse', 'skirt', 'womenPants', 'dress', 'sleeve'] as const) {
    const cfg = defaultConfig('female', garment, { seamAllowance: 1.0, sizeLabel: 'M' });
    const { pieces, warnings } = generatePattern(body, cfg);
    if (warnings.length) console.warn(garment, warnings);
    writeFileSync(`out/${garment}.svg`, new SvgRenderer({ seamAllowance: cfg.seamAllowance }).render(pieces));
    writeFileSync(`out/${garment}.dxf`, exportDxf(pieces, { seamAllowance: cfg.seamAllowance }));
    writeFileSync(`out/${garment}-a4.pdf`, await exportPdf(pieces, { seamAllowance: cfg.seamAllowance, tileA4: true }));
    writeFileSync(`out/${garment}-full.pdf`, await exportPdf(pieces, { seamAllowance: cfg.seamAllowance, tileA4: false }));
  }
  console.log('Arquivos gerados em ./out');
})();

/**
 * renderer.ts — Renderização SVG interativa. 1 unidade do viewBox = 1 cm (impressão em escala real).
 */
import { PatternPiece, Point, Segment, boundsOf, flatten, layoutPieces, seamOutline } from './geometry';

export interface RenderOptions {
  seamAllowance: number;
  showSeam: boolean; showGrain: boolean; showDarts: boolean; showLabels: boolean;
  interactive: boolean;   // pan (arrastar) + zoom (roda) + hover
  margin: number; gap: number; maxRowWidth: number;
}
const DEFAULTS: RenderOptions = {
  seamAllowance: 1, showSeam: true, showGrain: true, showDarts: true, showLabels: true,
  interactive: true, margin: 3, gap: 5, maxRowWidth: 140,
};

const f = (n: number) => String(+n.toFixed(3));
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export const segmentsToPath = (segs: Segment[]): string =>
  segs.map((s) => s.t === 'Z' ? 'Z' : s.t === 'C'
    ? `C${f(s.c1.x)} ${f(s.c1.y)} ${f(s.c2.x)} ${f(s.c2.y)} ${f(s.p.x)} ${f(s.p.y)}`
    : `${s.t}${f(s.p.x)} ${f(s.p.y)}`).join(' ');
export const polyToPath = (pts: Point[], closed = true): string =>
  pts.map((p, i) => `${i ? 'L' : 'M'}${f(p.x)} ${f(p.y)}`).join(' ') + (closed ? ' Z' : '');

const STYLE = `
.outline{fill:rgba(99,102,241,.06);stroke:#111;stroke-width:.08;stroke-linejoin:round}
.seam{fill:none;stroke:#888;stroke-width:.05;stroke-dasharray:.5 .3}
.dart{fill:none;stroke:#c2410c;stroke-width:.07}
.grain{stroke:#111;stroke-width:.06}.arrow{fill:#111}
.bp{fill:none;stroke:#be123c;stroke-width:.06}.bptxt{font:.9px sans-serif;fill:#be123c}
.notch{fill:#111}.lbl{font:1px sans-serif;text-anchor:middle;fill:#111}
.piece{cursor:pointer}.piece:hover .outline{stroke:#e11d48;fill:rgba(225,29,72,.08)}`;

// Script embutido (funciona quando o SVG é aberto direto ou inserido inline no HTML).
const SCRIPT = "(function(){var svg=document.currentScript.ownerSVGElement,vp=svg.getElementById('viewport'),s=1,tx=0,ty=0,d=null;" +
  "function pt(e){var p=svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;return p.matrixTransform(svg.getScreenCTM().inverse());}" +
  "function ap(){vp.setAttribute('transform','translate('+tx+' '+ty+') scale('+s+')');}" +
  "svg.addEventListener('wheel',function(e){e.preventDefault();var p=pt(e),k=e.deltaY<0?1.1:1/1.1;tx=p.x-(p.x-tx)*k;ty=p.y-(p.y-ty)*k;s*=k;ap();},{passive:false});" +
  "svg.addEventListener('pointerdown',function(e){d={p:pt(e),tx:tx,ty:ty};svg.setPointerCapture(e.pointerId);});" +
  "svg.addEventListener('pointermove',function(e){if(!d)return;var p=pt(e);tx=d.tx+(p.x-d.p.x);ty=d.ty+(p.y-d.p.y);ap();});" +
  "svg.addEventListener('pointerup',function(){d=null;});" +
  "svg.addEventListener('dblclick',function(){s=1;tx=0;ty=0;ap();});})();";

export class SvgRenderer {
  private o: RenderOptions;
  constructor(opts: Partial<RenderOptions> = {}) { this.o = { ...DEFAULTS, ...opts }; }

  render(pieces: PatternPiece[]): string {
    const o = this.o;
    const { pieces: laid, bounds } = layoutPieces(pieces, o.seamAllowance, o.gap, o.maxRowWidth);
    const vbx = bounds.minX - o.margin, vby = bounds.minY - o.margin;
    const w = bounds.maxX - bounds.minX + 2 * o.margin, h = bounds.maxY - bounds.minY + 2 * o.margin;

    const body = laid.map((p) => this.piece(p)).join('\n');
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${f(w)}cm" height="${f(h)}cm" viewBox="${f(vbx)} ${f(vby)} ${f(w)} ${f(h)}">
<style>${STYLE}</style>
<g id="viewport">
${body}
</g>
${o.interactive ? `<script><![CDATA[${SCRIPT}]]></script>` : ''}
</svg>`;
  }

  private piece(p: PatternPiece): string {
    const o = this.o, out: string[] = [];
    const poly = flatten(p.segments);
    const b = boundsOf(poly);
    out.push(`<g class="piece" id="piece-${esc(p.id)}" data-piece="${esc(p.id)}"><title>${esc(p.label ?? p.name)}</title>`);

    if (o.showSeam) out.push(`<path class="seam" d="${polyToPath(seamOutline(p, o.seamAllowance))}"/>`);
    out.push(`<path class="outline" d="${segmentsToPath(p.segments)}"/>`);

    if (o.showDarts) for (const d of p.darts) out.push(`<path class="dart" d="${polyToPath(d, false)}"/>`);

    if (o.showGrain) {
      const { from, to } = p.grain, a = 0.6, l = 1.2;
      out.push(`<line class="grain" x1="${f(from.x)}" y1="${f(from.y)}" x2="${f(to.x)}" y2="${f(to.y)}"/>`,
        `<path class="arrow" d="M${f(from.x)} ${f(from.y)}L${f(from.x - a)} ${f(from.y + l)}L${f(from.x + a)} ${f(from.y + l)}Z"/>`,
        `<path class="arrow" d="M${f(to.x)} ${f(to.y)}L${f(to.x - a)} ${f(to.y - l)}L${f(to.x + a)} ${f(to.y - l)}Z"/>`);
    }
    if (p.bustPoint) {
      const { x, y } = p.bustPoint;
      out.push(`<circle class="bp" cx="${f(x)}" cy="${f(y)}" r=".35"/>`,
        `<path class="bp" d="M${f(x - .6)} ${f(y)}H${f(x + .6)}M${f(x)} ${f(y - .6)}V${f(y + .6)}"/>`,
        `<text class="bptxt" x="${f(x + .6)}" y="${f(y - .6)}">BP</text>`);
    }
    for (const n of p.notches) out.push(`<circle class="notch" cx="${f(n.x)}" cy="${f(n.y)}" r=".2"/>`);
    if (o.showLabels && p.label)
      out.push(`<text class="lbl" x="${f((b.minX + b.maxX) / 2)}" y="${f((b.minY + b.maxY) / 2)}">${esc(p.label)}</text>`);
    out.push('</g>');
    return out.join('\n');
  }
}

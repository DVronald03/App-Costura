"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.seamOutline = exports.PathBuilder = exports.P = void 0;
exports.flatten = flatten;
exports.polylineLength = polylineLength;
exports.signedArea = signedArea;
exports.offsetPolygon = offsetPolygon;
exports.boundsOf = boundsOf;
exports.translatePiece = translatePiece;
exports.layoutPieces = layoutPieces;
const P = (x, y) => ({ x, y });
exports.P = P;
class PathBuilder {
    constructor() {
        this.segments = [];
    }
    M(x, y) { this.segments.push({ t: 'M', p: (0, exports.P)(x, y) }); return this; }
    L(x, y) { this.segments.push({ t: 'L', p: (0, exports.P)(x, y) }); return this; }
    C(x1, y1, x2, y2, x, y) {
        this.segments.push({ t: 'C', c1: (0, exports.P)(x1, y1), c2: (0, exports.P)(x2, y2), p: (0, exports.P)(x, y) });
        return this;
    }
    Z() { this.segments.push({ t: 'Z' }); return this; }
}
exports.PathBuilder = PathBuilder;
const cubic = (a, b, c, d, t) => {
    const u = 1 - t;
    return (0, exports.P)(u * u * u * a.x + 3 * u * u * t * b.x + 3 * u * t * t * c.x + t * t * t * d.x, u * u * u * a.y + 3 * u * u * t * b.y + 3 * u * t * t * c.y + t * t * t * d.y);
};
/** Converte segmentos (com Béziers) em polilinha. */
function flatten(segs, steps = 20) {
    const out = [];
    let cur = (0, exports.P)(0, 0);
    for (const s of segs) {
        if (s.t === 'M' || s.t === 'L') {
            out.push(s.p);
            cur = s.p;
        }
        else if (s.t === 'C') {
            for (let i = 1; i <= steps; i++)
                out.push(cubic(cur, s.c1, s.c2, s.p, i / steps));
            cur = s.p;
        }
    }
    const dedup = out.filter((p, i) => i === 0 || Math.hypot(p.x - out[i - 1].x, p.y - out[i - 1].y) > 1e-9);
    if (dedup.length > 1) {
        const f = dedup[0], l = dedup[dedup.length - 1];
        if (Math.hypot(f.x - l.x, f.y - l.y) < 1e-9)
            dedup.pop();
    }
    return dedup;
}
function polylineLength(pts, closed = false) {
    let len = 0;
    for (let i = 1; i < pts.length; i++)
        len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    if (closed && pts.length > 1)
        len += Math.hypot(pts[0].x - pts[pts.length - 1].x, pts[0].y - pts[pts.length - 1].y);
    return len;
}
function signedArea(poly) {
    let a = 0;
    for (let i = 0; i < poly.length; i++) {
        const p = poly[i], q = poly[(i + 1) % poly.length];
        a += p.x * q.y - q.x * p.y;
    }
    return a / 2;
}
/** Offset (miter) de polígono fechado para fora por distância d. */
function offsetPolygon(poly, d, miterLimit = 3) {
    const n = poly.length;
    if (n < 3)
        return poly.slice();
    const sgn = signedArea(poly) > 0 ? 1 : -1;
    const normals = poly.map((p, i) => {
        const q = poly[(i + 1) % n];
        const dx = q.x - p.x, dy = q.y - p.y;
        const len = Math.hypot(dx, dy) || 1;
        return (0, exports.P)((sgn * dy) / len, (-sgn * dx) / len); // normal externa
    });
    return poly.map((p, i) => {
        const n1 = normals[(i - 1 + n) % n], n2 = normals[i];
        const k = 1 / Math.max(1 + (n1.x * n2.x + n1.y * n2.y), 1e-6);
        let vx = (n1.x + n2.x) * k * d, vy = (n1.y + n2.y) * k * d;
        const mag = Math.hypot(vx, vy), max = Math.abs(d) * miterLimit;
        if (mag > max) {
            vx *= max / mag;
            vy *= max / mag;
        }
        return (0, exports.P)(p.x + vx, p.y + vy);
    });
}
const seamOutline = (piece, allowance) => offsetPolygon(flatten(piece.segments), allowance);
exports.seamOutline = seamOutline;
function boundsOf(pts) {
    return pts.reduce((b, p) => ({ minX: Math.min(b.minX, p.x), minY: Math.min(b.minY, p.y), maxX: Math.max(b.maxX, p.x), maxY: Math.max(b.maxY, p.y) }), { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity });
}
function translatePiece(piece, dx, dy) {
    const tp = (p) => (0, exports.P)(p.x + dx, p.y + dy);
    return {
        ...piece,
        segments: piece.segments.map((s) => s.t === 'Z' ? s : s.t === 'C' ? { t: 'C', c1: tp(s.c1), c2: tp(s.c2), p: tp(s.p) } : { t: s.t, p: tp(s.p) }),
        grain: { from: tp(piece.grain.from), to: tp(piece.grain.to) },
        darts: piece.darts.map((d) => d.map(tp)),
        bustPoint: piece.bustPoint && tp(piece.bustPoint),
        notches: piece.notches.map(tp),
    };
}
/** Dispõe as peças em linhas (com quebra) levando em conta a margem de costura. */
function layoutPieces(pieces, seamAllowance, gap = 5, maxRowWidth = 140) {
    const out = [];
    let x = 0, y = 0, rowH = 0;
    const all = [];
    for (const piece of pieces) {
        const b = boundsOf((0, exports.seamOutline)(piece, seamAllowance));
        const w = b.maxX - b.minX, h = b.maxY - b.minY;
        if (x > 0 && x + w > maxRowWidth) {
            x = 0;
            y += rowH + gap;
            rowH = 0;
        }
        out.push(translatePiece(piece, x - b.minX, y - b.minY));
        all.push((0, exports.P)(x, y), (0, exports.P)(x + w, y + h));
        x += w + gap;
        rowH = Math.max(rowH, h);
    }
    return { pieces: out, bounds: boundsOf(all) };
}

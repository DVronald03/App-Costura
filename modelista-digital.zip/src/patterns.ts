/**
 * patterns.ts — Gerador de coordenadas cartesianas (pontos + Béziers) de cada molde-base.
 * Convenção: cada peça é desenhada com seu centro (CF/CB) em x = 0; y = 0 na linha do ombro/pescoço
 * (blusa/camisa) ou na linha da cintura (calça/saia). Peças são "meio-molde" (cortar espelhado, 2x).
 */
import { PathBuilder, PatternPiece, Point, P, flatten, polylineLength } from './geometry';
import * as E from './engine';
import { BodyMeasurements, GarmentType, Gender, PatternConfig } from './schemas';

export interface PatternResult { pieces: PatternPiece[]; warnings: string[] }

const GARMENT_GENDER: Record<GarmentType, Gender | 'any'> = {
  skirt: 'female', womenPants: 'female', womenBlouse: 'female', dress: 'female',
  menPants: 'male', menShirt: 'male', sleeve: 'any',
};

export function generatePattern(body: BodyMeasurements, cfg: PatternConfig): PatternResult {
  if (body.gender !== cfg.gender) throw new Error('Gênero das medidas difere do gênero da configuração.');
  const allowed = GARMENT_GENDER[cfg.garment];
  if (allowed !== 'any' && allowed !== cfg.gender)
    throw new Error(`A peça "${cfg.garment}" não é válida para gênero "${cfg.gender}".`);

  const ease = cfg.easeTable[cfg.gender][cfg.fit];
  let pieces: PatternPiece[] = [];
  const warnings: string[] = [];

  switch (cfg.garment) {
    case 'womenBlouse': {
      const b = E.bodiceBasics(body, ease);
      pieces = [bodice(body, b, 'front', 'blusa'), bodice(body, b, 'back', 'blusa')];
      break;
    }
    case 'menShirt': {
      const b = E.bodiceBasics(body, ease);
      pieces = [bodice(body, b, 'front', 'camisa'), ...shirtBack(b)];
      break;
    }
    case 'womenPants':
    case 'menPants': {
      const pb = E.pantsBasics(body, ease);
      warnings.push(...pb.warnings);
      const id = cfg.garment;
      pieces = [pantsPiece(pb, 'front', id), pantsPiece(pb, 'back', id)];
      break;
    }
    case 'skirt': {
      if (body.gender !== 'female') throw new Error('unreachable');
      const sb = E.skirtBasics(body.data, ease);
      pieces = [skirtPiece(sb, 'front', 'skirt'), skirtPiece(sb, 'back', 'skirt')];
      break;
    }
    case 'dress': {
      if (body.gender !== 'female') throw new Error('unreachable');
      const b = E.bodiceBasics(body, ease);
      const sb = E.skirtBasics(body.data, ease);
      const edge = (s: 'front' | 'back') => b.chestQ - E.bodiceWaistShaping(b, 'female', s).sideReduction;
      pieces = [
        bodice(body, b, 'front', 'vestido-corpete'), bodice(body, b, 'back', 'vestido-corpete'),
        skirtPiece(sb, 'front', 'vestido-saia', edge('front')), skirtPiece(sb, 'back', 'vestido-saia', edge('back')),
      ];
      break;
    }
    case 'sleeve': {
      pieces = [sleevePiece(body, E.bodiceBasics(body, ease), ease.chest)];
      break;
    }
  }
  // Etiquetas: "Frente - Tamanho P - 2x Tecido"
  pieces = pieces.map((p) => ({ ...p, label: `${p.name} - Tamanho ${cfg.sizeLabel} - ${p.cutQty}x Tecido` }));
  return { pieces, warnings };
}

// ───────────────────────── Blusa / Camisa ─────────────────────────
function armholeBezier(from: Point, to: Point, inset: number) {
  return {
    c1: P(from.x - inset, from.y + (to.y - from.y) * 0.5),
    c2: P(to.x - (to.x - from.x) * 0.6, to.y),
    to,
  };
}
function neckCurve(pb: PathBuilder, neckW: number, depth: number) {
  pb.C(neckW * 0.6, depth, neckW, depth * 0.4, neckW, 0);
}

function bodice(body: BodyMeasurements, b: E.BodiceBasics, side: 'front' | 'back', prefix: string): PatternPiece {
  const F = side === 'front', female = body.gender === 'female';
  const W = b.chestQ, tipX = F ? b.tipXFront : b.tipXBack;
  const nd = F ? b.frontNeckDepth : b.backNeckDepth, hemY = F ? b.hemYFront : b.hemYBack;
  const shape = E.bodiceWaistShaping(b, body.gender, side);
  const xHem = W - shape.sideReduction;
  const tip = P(tipX, b.drop), armpit = P(W, b.armDepth);
  const placket = !female && F ? 2 : 0; // sobreposição de botões (camisa)

  const pb = new PathBuilder().M(0, nd);
  neckCurve(pb, b.neckW, nd);
  pb.L(tip.x, tip.y);
  const ah = armholeBezier(tip, armpit, F ? 1.2 : 0.6);
  pb.C(ah.c1.x, ah.c1.y, ah.c2.x, ah.c2.y, ah.to.x, ah.to.y);
  pb.L(xHem, hemY).L(-placket, hemY);
  if (placket) pb.L(-placket, nd);
  pb.Z();

  const sideX = (y: number) => W + (xHem - W) * ((y - b.armDepth) / (hemY - b.armDepth));
  const darts: Point[][] = [];
  let bp: Point | undefined;
  if (body.gender === 'female') {
    const bd = E.bustDart(body.data, b.armDepth);
    if (F) {
      bp = bd.bp;
      if (bd.amount > 0.2) {
        const apex = E.apexTowards(bp, P(sideX(bd.centerY), bd.centerY), bd.retreat);
        darts.push([P(sideX(bd.centerY - bd.amount / 2), bd.centerY - bd.amount / 2), apex,
                    P(sideX(bd.centerY + bd.amount / 2), bd.centerY + bd.amount / 2)]);
      }
    }
    if (shape.dartWidth > 0.2) {
      const cx = F && bp ? bp.x : W * 0.5, apexY = F && bp ? bp.y + 3 : b.armDepth + 2;
      darts.push([P(cx - shape.dartWidth / 2, hemY), P(cx, apexY), P(cx + shape.dartWidth / 2, hemY)]);
    }
  }
  const gx = W * 0.5;
  return {
    id: `${prefix}-${side}`, name: F ? 'Frente' : 'Costas', cutQty: 2, segments: pb.segments,
    grain: { from: P(gx, b.armDepth + 2), to: P(gx, hemY - 4) }, darts, bustPoint: bp, notches: [P(W, b.armDepth)],
  };
}

/** Costas da camisa masculina: Pala + corpo das costas (ombro estendido já em tipXBack). */
function shirtBack(b: E.BodiceBasics): PatternPiece[] {
  const yokeH = 8, W = b.chestQ, nd = b.backNeckDepth;
  const tip = P(b.tipXBack, b.drop), p1 = P(b.tipXBack - 0.8, yokeH), armpit = P(W, b.armDepth);
  const xHem = W - E.bodiceWaistShaping(b, 'male', 'back').sideReduction;

  const y = new PathBuilder().M(0, nd);
  neckCurve(y, b.neckW, nd);
  y.L(tip.x, tip.y).L(p1.x, p1.y).L(0, yokeH).Z();

  const ah = armholeBezier(p1, armpit, 0.6);
  const body = new PathBuilder().M(0, yokeH).L(p1.x, p1.y)
    .C(ah.c1.x, ah.c1.y, ah.c2.x, ah.c2.y, ah.to.x, ah.to.y)
    .L(xHem, b.hemYBack).L(0, b.hemYBack).Z();

  return [
    { id: 'camisa-yoke', name: 'Pala', cutQty: 2, segments: y.segments,
      grain: { from: P(b.tipXBack * 0.5, 1.5), to: P(b.tipXBack * 0.5, yokeH - 1.5) }, darts: [], notches: [P(0, yokeH)] },
    { id: 'camisa-back', name: 'Costas', cutQty: 1, segments: body.segments,
      grain: { from: P(W * 0.5, yokeH + 3), to: P(W * 0.5, b.hemYBack - 4) }, darts: [], notches: [P(0, yokeH)] },
  ];
}

// ───────────────────────── Calça ─────────────────────────
function pantsPiece(b: E.PantsBasics, side: 'front' | 'back', id: string): PatternPiece {
  const F = side === 'front';
  const ext = F ? b.frontExt : b.backExt, hipQ = F ? b.hipQFront : b.hipQBack;
  const x0 = F ? 0 : b.backSlant, raise = F ? 0 : b.backRaise, wTop = F ? b.waistFront : b.waistBack;
  const kw = F ? b.kneeFront : b.kneeBack, hw = F ? b.hemFront : b.hemBack;
  const plan = F ? b.dartsFront : b.dartsBack;
  const cy = F ? b.hipDepth + 0.35 * (b.crotchDepth - b.hipDepth) : b.hipDepth;
  const xc = (hipQ - ext) / 2;
  const yTop = -raise, wR = x0 + wTop;

  const pb = new PathBuilder().M(x0, yTop).L(wR, yTop)
    .C(wR, yTop + (b.hipDepth - yTop) * 0.35, hipQ, b.hipDepth * 0.6, hipQ, b.hipDepth)  // lateral (cintura → quadril)
    .L(xc + kw / 2, b.kneeY).L(xc + hw / 2, b.hemY)                                       // perna externa
    .L(xc - hw / 2, b.hemY).L(xc - kw / 2, b.kneeY).L(-ext, b.crotchDepth);               // barra + entreperna
  // curva do gancho (J) — frente é mais curta/fechada; costas mais profunda e inclinada
  pb.C(-ext * 0.45, b.crotchDepth + (F ? 0 : 0.5), 0 - (F ? 0 : ext * 0.05), cy + (b.crotchDepth - cy) * 0.55, 0, cy);
  pb.L(x0, yTop).Z();

  const darts: Point[][] = [];
  const len = (F ? 9 : 13) * (plan.count === 2 ? 0.85 : 1);
  for (let i = 0; i < plan.count; i++) {
    const cx = x0 + (wTop * (i + 1)) / (plan.count + 1);
    darts.push([P(cx - plan.width / 2, yTop), P(cx, yTop + len), P(cx + plan.width / 2, yTop)]);
  }
  return {
    id: `${id}-${side}`, name: F ? 'Frente' : 'Costas', cutQty: 2, segments: pb.segments,
    grain: { from: P(xc, b.hipDepth + 2), to: P(xc, b.hemY - 3) }, darts, notches: [P(xc, b.kneeY)],
  };
}

// ───────────────────────── Saia ─────────────────────────
function skirtPiece(sb: E.SkirtBasics, side: 'front' | 'back', id: string, waistOverride?: number): PatternPiece {
  const F = side === 'front', plan = F ? sb.dartsFront : sb.dartsBack;
  const wW = waistOverride ?? (F ? sb.waistFront : sb.waistBack), hipQ = sb.hipQ;
  const pb = new PathBuilder().M(0, 0).L(wW, 0)
    .C(wW, sb.hipDepth * 0.3, hipQ, sb.hipDepth * 0.6, hipQ, sb.hipDepth)
    .L(hipQ, sb.length).L(0, sb.length).Z();
  const darts: Point[][] = [];
  if (waistOverride === undefined) {
    const len = (F ? 9 : 13) * (plan.count === 2 ? 0.85 : 1);
    for (let i = 0; i < plan.count; i++) {
      const cx = (wW * (i + 1)) / (plan.count + 1);
      darts.push([P(cx - plan.width / 2, 0), P(cx, len), P(cx + plan.width / 2, 0)]);
    }
  }
  return {
    id: `${id}-${side}`, name: `${id.startsWith('vestido') ? 'Saia ' : ''}${F ? 'Frente' : 'Costas'}`, cutQty: 2,
    segments: pb.segments, grain: { from: P(hipQ * 0.5, 5), to: P(hipQ * 0.5, sb.length - 5) }, darts, notches: [P(0, sb.hipDepth)],
  };
}

// ───────────────────────── Manga ─────────────────────────
function sleevePiece(body: BodyMeasurements, b: E.BodiceBasics, chestEase: number): PatternPiece {
  const m = body.data;
  const armLen = (['front', 'back'] as const).reduce((acc, s) => {
    const tip = P(s === 'front' ? b.tipXFront : b.tipXBack, b.drop);
    const ah = armholeBezier(tip, P(b.chestQ, b.armDepth), s === 'front' ? 1.2 : 0.6);
    return acc + polylineLength(flatten([{ t: 'M', p: tip }, { t: 'C', c1: ah.c1, c2: ah.c2, p: ah.to }]));
  }, 0);
  const capH = armLen / 3;
  const w = (m.bicep ?? armLen * 0.68) + chestEase * 0.25;           // estimativa se não houver bíceps
  const wristW = (m.wrist ?? 16) + 4;
  const L = m.sleeveLength;
  const pb = new PathBuilder().M(0, capH)
    .C(w * 0.1, capH * 0.45, w * 0.3, 0, w / 2, 0)
    .C(w * 0.7, 0, w * 0.9, capH * 0.45, w, capH)
    .L(w / 2 + wristW / 2, L).L(w / 2 - wristW / 2, L).Z();
  return {
    id: 'sleeve', name: 'Manga', cutQty: 2, segments: pb.segments,
    grain: { from: P(w / 2, capH + 2), to: P(w / 2, L - 3) }, darts: [], notches: [P(w / 2, 0)],
  };
}

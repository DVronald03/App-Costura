/**
 * engine.ts — Motor de cálculo (funções puras): divisões, pences, ganchos e medidas-base.
 * Nada aqui desenha; apenas devolve números que o gerador de coordenadas consome.
 */
import { BodyMeasurements, EaseSet, FemaleMeasurements, Gender } from './schemas';
import { Point, P } from './geometry';

export const quarter = (circ: number, ease: number) => (circ + ease) / 4;
export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
export const MALE_DART_MIN = 1.5;
export const MALE_DART_MAX = 2.0;

// ───────────────────────── Pences de cintura ─────────────────────────
export interface DartPlan {
  count: 0 | 1 | 2;
  width: number;          // abertura de cada pence na cintura (cm)
  sideReduction: number;  // redução restante por painel, absorvida na curva lateral (informativo)
}

/**
 * Feminino. D = quadril - cintura (circunferências).
 *  D <= 12: 1 pence — frente D/8, costas D/6.
 *  D  > 12: 2 pences (orçamento dividido) + o restante vai para a curva lateral.
 * Redução necessária por painel = D/4.
 */
export function planFemaleDarts(waist: number, hip: number, panel: 'front' | 'back'): DartPlan {
  const D = hip - waist;
  if (D <= 0) return { count: 0, width: 0, sideReduction: 0 };
  const budget = panel === 'front' ? D / 8 : D / 6;
  const count: 1 | 2 = D <= 12 ? 1 : 2;
  return { count, width: budget / count, sideReduction: Math.max(0, D / 4 - budget) };
}

/** Masculino: só pence de costas, 1.5–2 cm no máximo. */
export function planMaleBackDart(waist: number, hip: number): DartPlan {
  const D = hip - waist;
  if (D <= 0) return { count: 0, width: 0, sideReduction: 0 };
  const width = clamp(D / 12, MALE_DART_MIN, MALE_DART_MAX);
  return { count: 1, width, sideReduction: Math.max(0, D / 4 - width) };
}

// ───────────────────────── Pence de busto ─────────────────────────
export interface BustDart {
  bp: Point;        // ponto de busto: (separação/2, altura do busto)
  amount: number;   // abertura da pence lateral = comprimento frente - costas
  centerY: number;  // altura do centro da abertura na lateral
  retreat: number;  // recuo do vértice em relação ao BP (cm)
}
export function bustDart(m: FemaleMeasurements, armDepth: number): BustDart {
  return {
    bp: P(m.bustSeparation / 2, m.bustHeight),
    amount: Math.max(0, m.frontLength - m.backLength),
    centerY: armDepth + 3,
    retreat: 2,
  };
}
/** Vértice = BP recuado `retreat` cm na direção da lateral (evita "bico"). */
export function apexTowards(bp: Point, target: Point, retreat: number): Point {
  const dx = target.x - bp.x, dy = target.y - bp.y, len = Math.hypot(dx, dy) || 1;
  return P(bp.x + (dx / len) * retreat, bp.y + (dy / len) * retreat);
}

// ───────────────────────── Corpo (blusa/camisa/vestido) ─────────────────────────
export interface BodiceBasics {
  chestQ: number; waistQ: number;
  neckW: number; frontNeckDepth: number; backNeckDepth: number;
  drop: number; armDepth: number;
  tipXFront: number; tipXBack: number;
  hemYFront: number; hemYBack: number;
}
const SHIRT_HEM_DROP = 28; // cm abaixo da cintura (barra da camisa)

export function bodiceBasics(body: BodyMeasurements, ease: EaseSet): BodiceBasics {
  if (body.gender === 'female') {
    const m = body.data, neckW = m.neck / 6, drop = 4;
    return {
      chestQ: quarter(m.fullBust, ease.chest), waistQ: quarter(m.waist, ease.waist),
      neckW, frontNeckDepth: neckW + 1, backNeckDepth: 2, drop, armDepth: m.armholeDepth,
      tipXFront: neckW + Math.sqrt(Math.max(0, m.shoulder ** 2 - drop ** 2)),
      tipXBack: neckW + Math.sqrt(Math.max(0, (m.shoulder + 0.7) ** 2 - drop ** 2)),
      hemYFront: m.frontLength, hemYBack: m.backLength,
    };
  }
  const m = body.data, neckW = m.neck / 6 + 0.5, extendedShoulder = 1.5; // ombro estendido
  return {
    chestQ: quarter(m.chest, ease.chest), waistQ: quarter(m.waist, ease.waist),
    neckW, frontNeckDepth: neckW, backNeckDepth: 2, drop: 5, armDepth: m.chest / 5 + 4,
    tipXFront: m.shoulderToShoulder / 2 + extendedShoulder,
    tipXBack: m.shoulderToShoulder / 2 + extendedShoulder + 0.5,
    hemYFront: m.frontLength + SHIRT_HEM_DROP, hemYBack: m.backLength + SHIRT_HEM_DROP,
  };
}

/** Quanto da diferença busto−cintura vai para pence e quanto para a lateral. */
export function bodiceWaistShaping(b: BodiceBasics, gender: Gender, panel: 'front' | 'back') {
  const total = Math.max(0, b.chestQ - b.waistQ);
  if (gender === 'female') {
    const dartWidth = Math.min(3.5, total * (panel === 'front' ? 0.5 : 0.6));
    return { dartWidth, sideReduction: total - dartWidth };
  }
  return { dartWidth: 0, sideReduction: Math.min(total * 0.25, MALE_DART_MAX) };
}

// ───────────────────────── Calça ─────────────────────────
export interface PantsBasics {
  hipDepth: number; crotchDepth: number; kneeY: number; hemY: number;
  frontExt: number; backExt: number;          // avanço do gancho
  backSlant: number; backRaise: number;       // inclinação/elevação das costas
  hipQFront: number; hipQBack: number;
  waistFront: number; waistBack: number;      // largura da cintura já incluindo pences
  dartsFront: DartPlan; dartsBack: DartPlan;
  kneeFront: number; kneeBack: number; hemFront: number; hemBack: number;
  warnings: string[];
}

export function pantsBasics(body: BodyMeasurements, ease: EaseSet): PantsBasics {
  const warnings: string[] = [];
  let hipC: number, waistC: number, hipDepth: number, crotchDepth: number, hemY: number;
  let dartsFront: DartPlan, dartsBack: DartPlan, backExt: number, backSlant: number, backRaise: number;
  let kneeC: number, hemC: number, thigh: number;

  if (body.gender === 'female') {
    const m = body.data;
    hipC = m.lowHip; waistC = m.waist; hipDepth = m.hipHeight; crotchDepth = m.crotchHeight + 1;
    hemY = m.pantsLength; kneeC = m.knee; hemC = m.hem; thigh = m.thigh;
    dartsFront = planFemaleDarts(waistC, hipC, 'front');
    dartsBack = planFemaleDarts(waistC, hipC, 'back');
    backExt = hipC / 8; backSlant = 2.5; backRaise = 1.5;
  } else {
    const m = body.data;
    hipC = m.hip; waistC = m.waist; hemY = m.outseam; crotchDepth = m.outseam - m.inseam;
    hipDepth = crotchDepth * 0.7; kneeC = m.knee; hemC = m.hem; thigh = m.thigh;
    dartsFront = { count: 0, width: 0, sideReduction: 0 };
    dartsBack = planMaleBackDart(waistC, hipC);
    backExt = hipC / 8 + 1;  // gavião mais largo nas costas
    backSlant = 3; backRaise = 2;
  }
  const frontExt = hipC / 16;
  const q = quarter(hipC, ease.hip), wq = quarter(waistC, ease.waist);
  const hipQFront = q - 1, hipQBack = q + 1;
  const waistFront = wq - 0.5 + dartsFront.count * dartsFront.width;
  const waistBack = wq + 0.5 + dartsBack.count * dartsBack.width;
  const kq = (kneeC + ease.thigh * 0.5) / 4;

  const crotchLevelWidth = hipQFront + frontExt + hipQBack + backExt;
  if (crotchLevelWidth < thigh + ease.thigh)
    warnings.push(`Largura no gancho (${crotchLevelWidth.toFixed(1)} cm) menor que coxa + folga (${(thigh + ease.thigh).toFixed(1)} cm).`);
  if (waistFront > hipQFront || waistBack > hipQBack)
    warnings.push('Cintura (com pences) maior que o quadril no painel — revise medidas.');

  return {
    hipDepth, crotchDepth, hemY, kneeY: crotchDepth + (hemY - crotchDepth) / 2 - 5,
    frontExt, backExt, backSlant, backRaise, hipQFront, hipQBack, waistFront, waistBack,
    dartsFront, dartsBack, kneeFront: kq - 1, kneeBack: kq + 1, hemFront: hemC / 4 - 1, hemBack: hemC / 4 + 1, warnings,
  };
}

// ───────────────────────── Saia ─────────────────────────
export interface SkirtBasics {
  hipQ: number; hipDepth: number; length: number;
  waistFront: number; waistBack: number;
  dartsFront: DartPlan; dartsBack: DartPlan;
}
export function skirtBasics(m: FemaleMeasurements, ease: EaseSet): SkirtBasics {
  const dartsFront = planFemaleDarts(m.waist, m.lowHip, 'front');
  const dartsBack = planFemaleDarts(m.waist, m.lowHip, 'back');
  const wq = quarter(m.waist, ease.waist);
  return {
    hipQ: quarter(m.lowHip, ease.hip), hipDepth: m.hipHeight, length: m.skirtLength,
    waistFront: wq + dartsFront.count * dartsFront.width,
    waistBack: wq + dartsBack.count * dartsBack.width,
    dartsFront, dartsBack,
  };
}

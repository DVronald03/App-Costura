"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const schemas_1 = require("./schemas");
const patterns_1 = require("./patterns");
const renderer_1 = require("./renderer");
const exporters_1 = require("./exporters");
const body = {
    gender: 'female',
    data: {
        fullBust: 92, highBust: 86, bustSeparation: 18, bustHeight: 26, frontLength: 42, backLength: 39.5,
        backWidth: 35, shoulder: 12.5, neck: 36, armholeDepth: 21, waist: 72, highHip: 88, lowHip: 98,
        hipHeight: 20, crotchHeight: 26, skirtLength: 60, pantsLength: 100, sleeveLength: 58, thigh: 58, knee: 38, hem: 34,
    },
};
(async () => {
    (0, fs_1.mkdirSync)('out', { recursive: true });
    for (const garment of ['womenBlouse', 'skirt', 'womenPants', 'dress', 'sleeve']) {
        const cfg = (0, schemas_1.defaultConfig)('female', garment, { seamAllowance: 1.0, sizeLabel: 'M' });
        const { pieces, warnings } = (0, patterns_1.generatePattern)(body, cfg);
        if (warnings.length)
            console.warn(garment, warnings);
        (0, fs_1.writeFileSync)(`out/${garment}.svg`, new renderer_1.SvgRenderer({ seamAllowance: cfg.seamAllowance }).render(pieces));
        (0, fs_1.writeFileSync)(`out/${garment}.dxf`, (0, exporters_1.exportDxf)(pieces, { seamAllowance: cfg.seamAllowance }));
        (0, fs_1.writeFileSync)(`out/${garment}-a4.pdf`, await (0, exporters_1.exportPdf)(pieces, { seamAllowance: cfg.seamAllowance, tileA4: true }));
        (0, fs_1.writeFileSync)(`out/${garment}-full.pdf`, await (0, exporters_1.exportPdf)(pieces, { seamAllowance: cfg.seamAllowance, tileA4: false }));
    }
    console.log('Arquivos gerados em ./out');
})();

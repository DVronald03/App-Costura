"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MALE_DART_MAX = exports.MALE_DART_MIN = exports.clamp = exports.quarter = void 0;
exports.planFemaleDarts = planFemaleDarts;
exports.planMaleBackDart = planMaleBackDart;
exports.bustDart = bustDart;
exports.apexTowards = apexTowards;
exports.bodiceBasics = bodiceBasics;
exports.bodiceWaistShaping = bodiceWaistShaping;
exports.pantsBasics = pantsBasics;
exports.skirtBasics = skirtBasics;
const geometry_1 = require("./geometry");
const quarter = (circ, ease) => (circ + ease) / 4;
exports.quarter = quarter;
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
exports.clamp = clamp;
exports.MALE_DART_MIN = 1.5;
exports.MALE_DART_MAX = 2.0;
/**
 * Feminino. D = quadril - cintura (circunferências).
 *  D <= 12: 1 pence — frente D/8, costas D/6.
 *  D  > 12: 2 pences (orçamento dividido) + o restante vai para a curva lateral.
 * Redução necessária por painel = D/4.
 */
function planFemaleDarts(waist, hip, panel) {
    const D = hip - waist;
    if (D <= 0)
        return { count: 0, width: 0, sideReduction: 0 };
    const budget = panel === 'front' ? D / 8 : D / 6;
    const count = D <= 12 ? 1 : 2;
    return { count, width: budget / count, sideReduction: Math.max(0, D / 4 - budget) };
}
/** Masculino: só pence de costas, 1.5–2 cm no máximo. */
function planMaleBackDart(waist, hip) {
    const D = hip - waist;
    if (D <= 0)
        return { count: 0, width: 0, sideReduction: 0 };
    const width = (0, exports.clamp)(D / 12, exports.MALE_DART_MIN, exports.MALE_DART_MAX);
    return { count: 1, width, sideReduction: Math.max(0, D / 4 - width) };
}
function bustDart(m, armDepth) {
    return {
        bp: (0, geometry_1.P)(m.bustSeparation / 2, m.bustHeight),
        amount: Math.max(0, m.frontLength - m.backLength),
        centerY: armDepth + 3,
        retreat: 2,
    };
}
/** Vértice = BP recuado `retreat` cm na direção da lateral (evita "bico"). */
function apexTowards(bp, target, retreat) {
    const dx = target.x - bp.x, dy = target.y - bp.y, len = Math.hypot(dx, dy) || 1;
    return (0, geometry_1.P)(bp.x + (dx / len) * retreat, bp.y + (dy / len) * retreat);
}
const SHIRT_HEM_DROP = 28; // cm abaixo da cintura (barra da camisa)
function bodiceBasics(body, ease) {
    if (body.gender === 'female') {
        const m = body.data, neckW = m.neck / 6, drop = 4;
        return {
            chestQ: (0, exports.quarter)(m.fullBust, ease.chest), waistQ: (0, exports.quarter)(m.waist, ease.waist),
            neckW, frontNeckDepth: neckW + 1, backNeckDepth: 2, drop, armDepth: m.armholeDepth,
            tipXFront: neckW + Math.sqrt(Math.max(0, m.shoulder ** 2 - drop ** 2)),
            tipXBack: neckW + Math.sqrt(Math.max(0, (m.shoulder + 0.7) ** 2 - drop ** 2)),
            hemYFront: m.frontLength, hemYBack: m.backLength,
        };
    }
    const m = body.data, neckW = m.neck / 6 + 0.5, extendedShoulder = 1.5; // ombro estendido
    return {
        chestQ: (0, exports.quarter)(m.chest, ease.chest), waistQ: (0, exports.quarter)(m.waist, ease.waist),
        neckW, frontNeckDepth: neckW, backNeckDepth: 2, drop: 5, armDepth: m.chest / 5 + 4,
        tipXFront: m.shoulderToShoulder / 2 + extendedShoulder,
        tipXBack: m.shoulderToShoulder / 2 + extendedShoulder + 0.5,
        hemYFront: m.frontLength + SHIRT_HEM_DROP, hemYBack: m.backLength + SHIRT_HEM_DROP,
    };
}
/** Quanto da diferença busto−cintura vai para pence e quanto para a lateral. */
function bodiceWaistShaping(b, gender, panel) {
    const total = Math.max(0, b.chestQ - b.waistQ);
    if (gender === 'female') {
        const dartWidth = Math.min(3.5, total * (panel === 'front' ? 0.5 : 0.6));
        return { dartWidth, sideReduction: total - dartWidth };
    }
    return { dartWidth: 0, sideReduction: Math.min(total * 0.25, exports.MALE_DART_MAX) };
}
function pantsBasics(body, ease) {
    const warnings = [];
    let hipC, waistC, hipDepth, crotchDepth, hemY;
    let dartsFront, dartsBack, backExt, backSlant, backRaise;
    let kneeC, hemC, thigh;
    if (body.gender === 'female') {
        const m = body.data;
        hipC = m.lowHip;
        waistC = m.waist;
        hipDepth = m.hipHeight;
        crotchDepth = m.crotchHeight + 1;
        hemY = m.pantsLength;
        kneeC = m.knee;
        hemC = m.hem;
        thigh = m.thigh;
        dartsFront = planFemaleDarts(waistC, hipC, 'front');
        dartsBack = planFemaleDarts(waistC, hipC, 'back');
        backExt = hipC / 8;
        backSlant = 2.5;
        backRaise = 1.5;
    }
    else {
        const m = body.data;
        hipC = m.hip;
        waistC = m.waist;
        hemY = m.outseam;
        crotchDepth = m.outseam - m.inseam;
        hipDepth = crotchDepth * 0.7;
        kneeC = m.knee;
        hemC = m.hem;
        thigh = m.thigh;
        dartsFront = { count: 0, width: 0, sideReduction: 0 };
        dartsBack = planMaleBackDart(waistC, hipC);
        backExt = hipC / 8 + 1; // gavião mais largo nas costas
        backSlant = 3;
        backRaise = 2;
    }
    const frontExt = hipC / 16;
    const q = (0, exports.quarter)(hipC, ease.hip), wq = (0, exports.quarter)(waistC, ease.waist);
    const hipQFront = q - 1, hipQBack = q + 1;
    const waistFront = wq - 0.5 + dartsFront.count * dartsFront.width;
    const waistBack = wq + 0.5 + dartsBack.count * dartsBack.width;
    const kq = (kneeC + ease.thigh * 0.5) / 4;
    const crotchLevelWidth = hipQFront + frontExt + hipQBack + backExt;
    if (crotchLevelWidth < thigh + ease.thigh)
        warnings.push(`Largura no gancho (${crotchLevelWidth.toFixed(1)} cm) menor que coxa + folga (${(thigh + ease.thigh).toFixed(1)} cm).`);
    if (waistFront > hipQFront || waistBack > hipQBack)
        warnings.push('Cintura (com pences) maior que o quadril no painel — revise medidas.');
    return {
        hipDepth, crotchDepth, hemY, kneeY: crotchDepth + (hemY - crotchDepth) / 2 - 5,
        frontExt, backExt, backSlant, backRaise, hipQFront, hipQBack, waistFront, waistBack,
        dartsFront, dartsBack, kneeFront: kq - 1, kneeBack: kq + 1, hemFront: hemC / 4 - 1, hemBack: hemC / 4 + 1, warnings,
    };
}
function skirtBasics(m, ease) {
    const dartsFront = planFemaleDarts(m.waist, m.lowHip, 'front');
    const dartsBack = planFemaleDarts(m.waist, m.lowHip, 'back');
    const wq = (0, exports.quarter)(m.waist, ease.waist);
    return {
        hipQ: (0, exports.quarter)(m.lowHip, ease.hip), hipDepth: m.hipHeight, length: m.skirtLength,
        waistFront: wq + dartsFront.count * dartsFront.width,
        waistBack: wq + dartsBack.count * dartsBack.width,
        dartsFront, dartsBack,
    };
}

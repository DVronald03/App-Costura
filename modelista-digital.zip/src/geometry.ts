/**
 * geometry.ts — Primitivas 2D: pontos, Béziers, flatten, offset de margem de costura e layout.
 * Sistema de coordenadas: x → direita, y → para baixo (origem no canto superior esquerdo).
 */
export interface Point { x: number; y: number }
export const P = (x: number, y: number): Point => ({ x, y });

export type Segment =
  | { t: 'M' | 'L'; p: Point }
  | { t: 'C'; c1: Point; c2: Point; p: Point } // Bézier cúbica (controlPoints = c1, c2)
  | { t: 'Z' };

export interface PatternPiece {
  id: string;
  name: string;
  label?: string;
  cutQty: number;
  segments: Segment[];
  grain: { from: Point; to: Point };
  darts: Point[][];        // cada pence: [pernaA, vértice, pernaB]
  bustPoint?: Point;       // BP
  notches: Point[];
}

export class PathBuilder {
  readonly segments: Segment[] = [];
  M(x: number, y: number) { this.segments.push({ t: 'M', p: P(x, y) }); return this; }
  L(x: number, y: number) { this.segments.push({ t: 'L', p: P(x, y) }); return this; }
  C(x1: number, y1: number, x2: number, y2: number, x: number, y: number) {
    this.segments.push({ t: 'C', c1: P(x1, y1), c2: P(x2, y2), p: P(x, y) });
    return this;
  }
  Z() { this.segments.push({ t: 'Z' }); return this; }
}

const cubic = (a: Point, b: Point, c: Point, d: Point, t: number): Point => {
  const u = 1 - t;
  return P(
    u * u * u * a.x + 3 * u * u * t * b.x + 3 * u * t * t * c.x + t * t * t * d.x,
    u * u * u * a.y + 3 * u * u * t * b.y + 3 * u * t * t * c.y + t * t * t * d.y,
  );
};

/** Converte segmentos (com Béziers) em polilinha. */
export function flatten(segs: Segment[], steps = 20): Point[] {
  const out: Point[] = [];
  let cur = P(0, 0);
  for (const s of segs) {
    if (s.t === 'M' || s.t === 'L') { out.push(s.p); cur = s.p; }
    else if (s.t === 'C') {
      for (let i = 1; i <= steps; i++) out.push(cubic(cur, s.c1, s.c2, s.p, i / steps));
      cur = s.p;
    }
  }
  const dedup = out.filter((p, i) => i === 0 || Math.hypot(p.x - out[i - 1].x, p.y - out[i - 1].y) > 1e-9);
  if (dedup.length > 1) {
    const f = dedup[0], l = dedup[dedup.length - 1];
    if (Math.hypot(f.x - l.x, f.y - l.y) < 1e-9) dedup.pop();
  }
  return dedup;
}

export function polylineLength(pts: Point[], closed = false): number {
  let len = 0;
  for (let i = 1; i < pts.length; i++) len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  if (closed && pts.length > 1) len += Math.hypot(pts[0].x - pts[pts.length - 1].x, pts[0].y - pts[pts.length - 1].y);
  return len;
}

export function signedArea(poly: Point[]): number {
  let a = 0;
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i], q = poly[(i + 1) % poly.length];
    a += p.x * q.y - q.x * p.y;
  }
  return a / 2;
}

/** Offset (miter) de polígono fechado para fora por distância d. */
export function offsetPolygon(poly: Point[], d: number, miterLimit = 3): Point[] {
  const n = poly.length;
  if (n < 3) return poly.slice();
  const sgn = signedArea(poly) > 0 ? 1 : -1;
  const normals = poly.map((p, i) => {
    const q = poly[(i + 1) % n];
    const dx = q.x - p.x, dy = q.y - p.y;
    const len = Math.hypot(dx, dy) || 1;
    return P((sgn * dy) / len, (-sgn * dx) / len); // normal externa
  });
  return poly.map((p, i) => {
    const n1 = normals[(i - 1 + n) % n], n2 = normals[i];
    const k = 1 / Math.max(1 + (n1.x * n2.x + n1.y * n2.y), 1e-6);
    let vx = (n1.x + n2.x) * k * d, vy = (n1.y + n2.y) * k * d;
    const mag = Math.hypot(vx, vy), max = Math.abs(d) * miterLimit;
    if (mag > max) { vx *= max / mag; vy *= max / mag; }
    return P(p.x + vx, p.y + vy);
  });
}

export const seamOutline = (piece: PatternPiece, allowance: number): Point[] =>
  offsetPolygon(flatten(piece.segments), allowance);

export interface Bounds { minX: number; minY: number; maxX: number; maxY: number }
export function boundsOf(pts: Point[]): Bounds {
  return pts.reduce<Bounds>(
    (b, p) => ({ minX: Math.min(b.minX, p.x), minY: Math.min(b.minY, p.y), maxX: Math.max(b.maxX, p.x), maxY: Math.max(b.maxY, p.y) }),
    { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity },
  );
}

export function translatePiece(piece: PatternPiece, dx: number, dy: number): PatternPiece {
  const tp = (p: Point) => P(p.x + dx, p.y + dy);
  return {
    ...piece,
    segments: piece.segments.map((s): Segment =>
      s.t === 'Z' ? s : s.t === 'C' ? { t: 'C', c1: tp(s.c1), c2: tp(s.c2), p: tp(s.p) } : { t: s.t, p: tp(s.p) }),
    grain: { from: tp(piece.grain.from), to: tp(piece.grain.to) },
    darts: piece.darts.map((d) => d.map(tp)),
    bustPoint: piece.bustPoint && tp(piece.bustPoint),
    notches: piece.notches.map(tp),
  };
}

/** Dispõe as peças em linhas (com quebra) levando em conta a margem de costura. */
export function layoutPieces(pieces: PatternPiece[], seamAllowance: number, gap = 5, maxRowWidth = 140) {
  const out: PatternPiece[] = [];
  let x = 0, y = 0, rowH = 0;
  const all: Point[] = [];
  for (const piece of pieces) {
    const b = boundsOf(seamOutline(piece, seamAllowance));
    const w = b.maxX - b.minX, h = b.maxY - b.minY;
    if (x > 0 && x + w > maxRowWidth) { x = 0; y += rowH + gap; rowH = 0; }
    out.push(translatePiece(piece, x - b.minX, y - b.minY));
    all.push(P(x, y), P(x + w, y + h));
    x += w + gap;
    rowH = Math.max(rowH, h);
  }
  return { pieces: out, bounds: boundsOf(all) };
}

# Modelista Digital — núcleo de moldes 2D

```
src/schemas.ts    modelo de dados (medidas F/M, folgas, config)
src/geometry.ts   pontos, Béziers, flatten, offset da margem de costura, layout
src/engine.ts     cálculo puro: divisões, pences, gancho, medidas-base
src/patterns.ts   gerador de coordenadas (blusa, camisa c/ pala, calças, saia, vestido, manga)
src/renderer.ts   SVG interativo (1 unidade = 1 cm; pan/zoom/hover)
src/exporters.ts  PDF vetorial (página única ou grade A4) e DXF
src/demo.ts       exemplo completo (npm run demo)
```

## Uso
```ts
const cfg = defaultConfig('female', 'womenBlouse', { seamAllowance: 1.5, sizeLabel: 'P', fit: 'comfortable' });
const { pieces, warnings } = generatePattern(body, cfg);
const svg = new SvgRenderer({ seamAllowance: cfg.seamAllowance }).render(pieces);
const pdf = await exportPdf(pieces, { seamAllowance: cfg.seamAllowance, tileA4: true });
const dxf = exportDxf(pieces, { seamAllowance: cfg.seamAllowance });
```

## Decisões de interpretação (ajuste em engine.ts)
- "Profundidade" da pence = abertura (largura) na cintura. D>12: orçamento de pence dividido em 2; o resto vai para a curva lateral.
- Avanço do gancho nas costas: `Quadril/4 - 2` daria ~23 cm (não é um avanço); usei `Quadril/8` (fem.) e `Quadril/8 + 1` (masc.). Frente = `Quadril/16`.
- `cava` = profundidade da cava. `highBust`/`backWidth` estão no schema mas ainda não alimentam a geometria.
- Curvas (cava, gancho, cabeça da manga) são aproximações paramétricas iniciais: calibre com provas reais.
- Peças são meio-moldes (CF/CB em x=0), cortar espelhado (2x).
